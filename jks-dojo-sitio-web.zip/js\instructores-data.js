/**
 * Base de datos de Instructores de JKS México y JKS Japón (Honbu Dojo)
 */
const INSTRUCTORES_DATA = {
  mexico: [
    {
      id: "inst-mx-1",
      nombre: "Shihan Roberto González",
      grado: "6° Dan JKS / Shihan",
      cargo: "Director Técnico Nacional - JKS México",
      ubicacion: "CDMX / Honbu Dojo México",
      experiencia: "38 años de práctica continua",
      especialidad: "Kata Tradicional Shotokan & Asai-Ryu, Bunkai y Filosofía del Budo",
      foto: "assets/images/sensei_mx_1.svg",
      biografia: "Graduado y certificado directamente por el Honbu Dojo de JKS en Tokio, Japón. Ha sido pionero en la difusión del estilo y técnicas del Maestro Tetsuhiko Asai en territorio mexicano. Representante oficial de JKS en seminarios panamericanos e internacionales.",
      logros: [
        "Juez y Árbitro Internacional certificado por JKS Japón",
        "Formador de más de 40 cinturones negros y campeones nacionales",
        "Coordinador de los Seminarios Internacionales JKS en México"
      ]
    },
    {
      id: "inst-mx-2",
      nombre: "Sensei Claudia Mendoza",
      grado: "4° Dan JKS",
      cargo: "Comisión Técnica Femenil y Desarrollo Infantil",
      ubicacion: "Ciudad de México",
      experiencia: "22 años de práctica",
      especialidad: "Pedagogía del Karate Infantil, Kihon y Kata Avanzado",
      foto: "assets/images/sensei_mx_2.svg",
      biografia: "Especialista en desarrollo psicomotriz a través del Karate-Do tradicional para niños y jóvenes. Ha participado en múltiples campamentos de entrenamiento en Japón y es una promotora activa de la inclusión y disciplina marcial en México.",
      logros: [
        "Medallista en el Campeonato Panamericano JKS",
        "Certificación de Instructora Clase B por JKS Honbu Dojo Tokio",
        "Directora del programa 'Karate y Valores para la Juventud'"
      ]
    },
    {
      id: "inst-mx-3",
      nombre: "Sensei Alejandro Vargas",
      grado: "5° Dan JKS",
      cargo: "Coordinador Regional Occidente & Kumite Coach",
      ubicacion: "Guadalajara, Jalisco",
      experiencia: "28 años de práctica",
      especialidad: "Kumite Deportivo y Tradicional, Tácticas de Combate",
      foto: "assets/images/sensei_mx_3.svg",
      biografia: "Ex-competidor internacional y entrenador de selecciones estatales. Su metodología combina el rigor técnico del Karate Shotokan con el dinamismo del combate moderno y el acondicionamiento físico de alto impacto.",
      logros: [
        "Múltiple campeón nacional de Kumite",
        "Entrenador del equipo representativo de Jalisco en torneos JKS",
        "Certificación de Arbitraje Internacional JKS"
      ]
    },
    {
      id: "inst-mx-4",
      nombre: "Sensei David Morales",
      grado: "5° Dan JKS",
      cargo: "Coordinador Regional Norte & Kata Specialist",
      ubicacion: "Monterrey, Nuevo León",
      experiencia: "30 años de práctica",
      especialidad: "Katas Superiores JKS, Bunkai Aplicado y Acondicionamiento",
      foto: "assets/images/sensei_mx_4.svg",
      biografia: "Líder de la expansión de JKS en el norte del país. Reconocido por su precisión geométrica en la ejecución de katas y su dedicación a la enseñanza de la historia y el espíritu del karate.",
      logros: [
        "Organizador de la Copa Norteña JKS con más de 300 atletas",
        "Examinador oficial de Grados Kyu y Dan autorizado por JKS",
        "Seminarios impartidos en EE.UU. y México"
      ]
    }
  ],
  japon: [
    {
      id: "inst-jp-1",
      nombre: "Tetsuhiko Asai Shihan (1935 - 2006)",
      grado: "10° Dan (Póstumo) / Fundador JKS",
      cargo: "Fundador de la Japan Karate Shoto Federation (JKS)",
      ubicacion: "Tokio, Japón",
      experiencia: "Leyenda Histórica del Karate Mundial",
      especialidad: "Creación del estilo Asai-Ryu Kata, Técnicas de Junro y Kakuyoku",
      foto: "assets/images/master_asai.svg",
      biografia: "Graduado de la Universidad de Takushoku (Takudai) y alumno directo del maestro Masatoshi Nakayama y Gichin Funakoshi. Legendario por su increíble flexibilidad, fluidez circular y técnica revolucionaria que enriqueció el Karate Shotokan tradicional.",
      logros: [
        "Fundó la Japan Karate Shoto Federation (NPO JKS) en el año 2000",
        "Creó los Katas de la serie Junro y Katas avanzados como Kakuyoku y Suishu",
        "Llevó el Karate a más de 80 países en los 5 continentes"
      ]
    },
    {
      id: "inst-jp-2",
      nombre: "Masao Kagawa Shihan",
      grado: "9° Dan JKS",
      cargo: "Director Técnico Mundial (World Chief Instructor JKS)",
      ubicacion: "Honbu Dojo, Sugamo, Tokio, Japón",
      experiencia: "Más de 50 años en la élite del Karate",
      especialidad: "Keri-waza (técnicas de pierna legendarias), Kihon de Potencia y Kumite",
      foto: "assets/images/master_kagawa.svg",
      biografia: "Uno de los más grandes maestros de karate vivos del planeta. Alumno destacado de Asai Sensei y de la Universidad de Teikyo. Famoso en todo el mundo por su flexibilidad extrema, patadas devastadoras y su estricta enseñanza del Budo.",
      logros: [
        "Gran Campeón Mundial de Kata y Kumite en el mismo torneo internacional",
        "Presidente de la Comisión Técnica de la Federación Mundial de Karate (WKF)",
        "Líder del legendario equipo de Karate de la Universidad de Teikyo"
      ]
    },
    {
      id: "inst-jp-3",
      nombre: "Kousaku Yokota Shihan",
      grado: "8° Dan",
      cargo: "Maestro Investigador y Autor de Artes Marciales",
      ubicacion: "Japón / Internacional",
      experiencia: "Más de 45 años de entrenamiento y docencia",
      especialidad: "Historia del Budo, Bunkai profundo y Biomecánica del Shotokan",
      foto: "assets/images/master_yokota.svg",
      biografia: "Autor de prestigiosos libros de karate tradicional y referente técnico en el análisis histórico y práctico de las técnicas originales de Okinawa y Japón.",
      logros: [
        "Autor de 'Shotokan Myths' y 'Karate Masterclass'",
        "Seminarios impartidos en más de 30 países",
        "Investigador y divulgador del legado de Asai Sensei"
      ]
    },
    {
      id: "inst-jp-4",
      nombre: "Koshiro Saida Sensei",
      grado: "5° Dan JKS",
      cargo: "Instructor del Honbu Dojo Tokio & Campeón Mundial",
      ubicacion: "Tokio, Japón",
      experiencia: "Joven promesa y referente de la nueva generación",
      especialidad: "Kata de Competición, Velocidad y Precisión Milimétrica",
      foto: "assets/images/master_saida.svg",
      biografia: "Instructor activo en el Honbu Dojo de Sugamo, Tokio. Imparte los entrenamientos para cinturones negros y delegaciones internacionales que visitan Japón para capacitarse.",
      logros: [
        "Campeón Internacional JKS en Kata individual",
        "Instructor titular en el Curso Internacional de Kenshusei JKS",
        "Docente en seminarios juveniles en Asia y Europa"
      ]
    }
  ]
};
