/**
 * JKS Karate-Do México & Internacional - Controlador Principal
 * 100% Vanilla JavaScript - Sin dependencias externas
 */

document.addEventListener('DOMContentLoaded', () => {
  initNavigation();
  initDojosSection();
  initInstructoresSection();
  initWorldSection();
  initFaqAccordion();
  initContactForm();
  initScrollAnimations();
});

/* ==========================================================================
   1. NAVEGACIÓN Y MENÚ MÓVIL
   ========================================================================== */
function initNavigation() {
  const header = document.querySelector('.site-header');
  const menuBtn = document.querySelector('.mobile-menu-btn');
  const navMenu = document.querySelector('.nav-links');
  const navLinks = document.querySelectorAll('.nav-link');

  // Sticky header blur effect
  window.addEventListener('scroll', () => {
    if (window.scrollY > 50) {
      header.classList.add('scrolled');
    } else {
      header.classList.remove('scrolled');
    }
  });

  // Mobile menu toggle
  if (menuBtn && navMenu) {
    menuBtn.addEventListener('click', () => {
      const isOpen = navMenu.classList.toggle('active');
      menuBtn.setAttribute('aria-expanded', isOpen);
      menuBtn.classList.toggle('open');
    });

    // Close mobile menu when clicking a link
    navLinks.forEach(link => {
      link.addEventListener('click', () => {
        navMenu.classList.remove('active');
        menuBtn.classList.remove('open');
        menuBtn.setAttribute('aria-expanded', 'false');
      });
    });
  }

  // Active link highlight on scroll (ScrollSpy)
  const sections = document.querySelectorAll('section[id]');
  window.addEventListener('scroll', () => {
    const scrollY = window.pageYOffset;
    sections.forEach(current => {
      const sectionHeight = current.offsetHeight;
      const sectionTop = current.offsetTop - 120;
      const sectionId = current.getAttribute('id');
      const matchingLink = document.querySelector(`.nav-link[href*="${sectionId}"]`);
      
      if (matchingLink) {
        if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
          matchingLink.classList.add('active');
        } else {
          matchingLink.classList.remove('active');
        }
      }
    });
  });
}

/* ==========================================================================
   2. SECCIÓN: DOJOS MÉXICO (Buscador y Filtros por Estado)
   ========================================================================== */
function initDojosSection() {
  const dojosContainer = document.getElementById('dojos-grid');
  const searchInput = document.getElementById('dojo-search');
  const filterButtonsContainer = document.getElementById('dojo-filters');
  const dojosCount = document.getElementById('dojos-count');

  if (!dojosContainer || typeof DOJOS_MEXICO === 'undefined') return;

  // Extraer estados únicos
  const estados = ['Todos', ...new Set(DOJOS_MEXICO.map(d => d.estado))];
  let estadoSeleccionado = 'Todos';
  let terminoBusqueda = '';

  // Renderizar botones de filtro
  if (filterButtonsContainer) {
    filterButtonsContainer.innerHTML = estados.map(estado => `
      <button class="filter-btn ${estado === 'Todos' ? 'active' : ''}" data-estado="${estado}">
        ${estado}
      </button>
    `).join('');

    filterButtonsContainer.addEventListener('click', (e) => {
      if (e.target.classList.contains('filter-btn')) {
        document.querySelectorAll('.filter-btn').forEach(btn => btn.classList.remove('active'));
        e.target.classList.add('active');
        estadoSeleccionado = e.target.dataset.estado;
        renderDojos();
      }
    });
  }

  // Búsqueda en tiempo real
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      terminoBusqueda = e.target.value.toLowerCase().trim();
      renderDojos();
    });
  }

  // Renderizado dinámico de tarjetas
  function renderDojos() {
    const filtrados = DOJOS_MEXICO.filter(dojo => {
      const coincideEstado = estadoSeleccionado === 'Todos' || dojo.estado === estadoSeleccionado;
      const coincideTexto = 
        dojo.nombre.toLowerCase().includes(terminoBusqueda) ||
        dojo.ciudad.toLowerCase().includes(terminoBusqueda) ||
        dojo.instructor.toLowerCase().includes(terminoBusqueda) ||
        dojo.direccion.toLowerCase().includes(terminoBusqueda) ||
        dojo.tags.some(tag => tag.toLowerCase().includes(terminoBusqueda));
      return coincideEstado && coincideTexto;
    });

    if (dojosCount) {
      dojosCount.textContent = `Mostrando ${filtrados.length} ${filtrados.length === 1 ? 'dojo' : 'dojos'} en México`;
    }

    if (filtrados.length === 0) {
      dojosContainer.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">🥋</div>
          <h3>No se encontraron dojos</h3>
          <p>Intenta con otro término de búsqueda o selecciona "Todos" para ver todas las sedes registradas.</p>
        </div>
      `;
      return;
    }

    dojosContainer.innerHTML = filtrados.map(dojo => `
      <article class="dojo-card ${dojo.destacado ? 'destacado' : ''}" id="${dojo.id}">
        ${dojo.destacado ? '<span class="badge-destacado"><span class="icon">★</span> Sede Principal</span>' : ''}
        <div class="dojo-card-header">
          <div class="dojo-state-badge">${dojo.estado}</div>
          <h3 class="dojo-title">${dojo.nombre}</h3>
          <p class="dojo-city"><span class="icon-geo">📍</span> ${dojo.ciudad}</p>
        </div>
        
        <div class="dojo-card-body">
          <div class="dojo-info-row">
            <span class="info-label">Instructor a cargo:</span>
            <span class="info-value sensei-name"><strong>${dojo.instructor}</strong> (${dojo.grado})</span>
          </div>

          <div class="dojo-info-row">
            <span class="info-label">Dirección:</span>
            <span class="info-value">${dojo.direccion}</span>
          </div>

          <div class="dojo-info-row">
            <span class="info-label">Horarios:</span>
            <span class="info-value">${dojo.horarios}</span>
          </div>

          <div class="dojo-tags">
            ${dojo.tags.map(tag => `<span class="tag-chip">${tag}</span>`).join('')}
          </div>
        </div>

        <div class="dojo-card-footer">
          <a href="https://wa.me/${dojo.whatsapp}?text=Hola,%20me%20gustaría%20solicitar%20informes%20para%20clases%20en%20${encodeURIComponent(dojo.nombre)}" 
             target="_blank" 
             rel="noopener noreferrer" 
             class="btn-dojo-contact">
             <span>💬 Contactar por WhatsApp</span>
          </a>
          <a href="https://maps.google.com/?q=${encodeURIComponent(dojo.direccion)}" 
             target="_blank" 
             rel="noopener noreferrer" 
             class="btn-dojo-map" 
             title="Ver en Google Maps">
             <span>🗺️ Mapa</span>
          </a>
        </div>
      </article>
    `).join('');
  }

  // Render inicial
  renderDojos();
}

/* ==========================================================================
   3. SECCIÓN: INSTRUCTORES (México y Japón) + Modales
   ========================================================================== */
function initInstructoresSection() {
  const mxContainer = document.getElementById('instructores-mx-grid');
  const jpContainer = document.getElementById('instructores-jp-grid');

  if (typeof INSTRUCTORES_DATA === 'undefined') return;

  // Render Instructores México
  if (mxContainer && INSTRUCTORES_DATA.mexico) {
    mxContainer.innerHTML = INSTRUCTORES_DATA.mexico.map(inst => createInstructorCard(inst, 'mx')).join('');
  }

  // Render Instructores Japón
  if (jpContainer && INSTRUCTORES_DATA.japon) {
    jpContainer.innerHTML = INSTRUCTORES_DATA.japon.map(inst => createInstructorCard(inst, 'jp')).join('');
  }

  // Modal handlers
  setupInstructorModal();
}

function createInstructorCard(instructor, origin) {
  const isJapan = origin === 'jp';
  return `
    <article class="instructor-card ${isJapan ? 'card-japan' : ''}" data-id="${instructor.id}">
      <div class="instructor-avatar-wrap">
        <div class="avatar-badge">${instructor.grado}</div>
        <div class="instructor-avatar-placeholder">
          <span class="kanji-watermark">${isJapan ? '武道' : '師範'}</span>
          <span class="instructor-initials">${instructor.nombre.split(' ').map(n => n[0]).slice(0,2).join('')}</span>
        </div>
      </div>

      <div class="instructor-content">
        <h3 class="instructor-name">${instructor.nombre}</h3>
        <p class="instructor-role">${instructor.cargo}</p>
        <p class="instructor-location">📍 ${instructor.ubicacion}</p>
        <p class="instructor-exp">⏱️ ${instructor.experiencia}</p>
        
        <p class="instructor-summary">${instructor.biografia.substring(0, 130)}...</p>

        <button class="btn-instructor-detail" onclick="openInstructorModal('${instructor.id}')">
          Ver Perfil Completo y Logros →
        </button>
      </div>
    </article>
  `;
}

function setupInstructorModal() {
  const modal = document.getElementById('instructor-modal');
  const closeBtn = document.querySelector('.modal-close-btn');

  if (!modal) return;

  const closeModal = () => {
    modal.classList.remove('active');
    document.body.style.overflow = '';
  };

  if (closeBtn) closeBtn.addEventListener('click', closeModal);
  modal.addEventListener('click', (e) => {
    if (e.target === modal) closeModal();
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modal.classList.contains('active')) {
      closeModal();
    }
  });
}

// Función global accesible para onclick
window.openInstructorModal = function(instructorId) {
  const modal = document.getElementById('instructor-modal');
  const modalBody = document.getElementById('modal-instructor-content');
  if (!modal || !modalBody || typeof INSTRUCTORES_DATA === 'undefined') return;

  const allInstructors = [...(INSTRUCTORES_DATA.mexico || []), ...(INSTRUCTORES_DATA.japon || [])];
  const instructor = allInstructors.find(inst => inst.id === instructorId);

  if (!instructor) return;

  modalBody.innerHTML = `
    <div class="modal-instructor-header">
      <div class="modal-badge">${instructor.grado}</div>
      <h2>${instructor.nombre}</h2>
      <p class="modal-subtitle">${instructor.cargo}</p>
      <div class="modal-meta-row">
        <span>📍 ${instructor.ubicacion}</span>
        <span>⏱️ ${instructor.experiencia}</span>
      </div>
    </div>

    <div class="modal-instructor-body">
      <div class="modal-section">
        <h4>Especialidad Técnica</h4>
        <p class="specialty-text">🥋 ${instructor.especialidad}</p>
      </div>

      <div class="modal-section">
        <h4>Trayectoria & Biografía</h4>
        <p>${instructor.biografia}</p>
      </div>

      <div class="modal-section">
        <h4>Logros & Certificaciones</h4>
        <ul class="achievements-list">
          ${instructor.logros.map(logro => `<li><span class="bullet">⛩️</span> ${logro}</li>`).join('')}
        </ul>
      </div>
    </div>
  `;

  modal.classList.add('active');
  document.body.style.overflow = 'hidden';
};

/* ==========================================================================
   4. SECCIÓN: JKS EN EL MUNDO (Pestañas y Estadísticas)
   ========================================================================== */
function initWorldSection() {
  const tabs = document.querySelectorAll('.world-tab-btn');
  const worldDataContainer = document.getElementById('world-region-data');

  const REGIONES = {
    america: {
      nombre: "América",
      paises: ["México (Sede Nacional)", "Estados Unidos", "Canadá", "Brasil", "Argentina", "Chile", "Colombia", "Perú", "Costa Rica", "Panamá", "Uruguay"],
      dojosCount: "250+ Dojos",
      eventos: "Campeonatos Panamericanos Bianuales, Seminarios del Honbu Dojo en CDMX y São Paulo.",
      descripcion: "La región de América cuenta con un crecimiento acelerado en la difusión del karate Shotokan tradicional y el estilo Asai-Ryu, con instructores formados en Japón."
    },
    europa: {
      nombre: "Europa",
      paises: ["JKS Inglaterra (Honbu Europa)", "Escocia", "Alemania", "Italia", "España", "Francia", "Irlanda", "Suiza", "Dinamarca", "Polonia", "Hungría"],
      dojosCount: "450+ Dojos",
      eventos: "Seminarios Internacionales de Primavera, Copa Europea JKS, Cursos de Instructores Kenshusei.",
      descripcion: "Una de las fortalezas históricas de JKS a nivel internacional, con alta competencia técnica y seminarios periódicos encabezados por Masao Kagawa Shihan."
    },
    asia: {
      nombre: "Asia y Oceanía",
      paises: ["Japón (Honbu Dojo Tokio)", "Australia", "Nueva Zelanda", "India", "Sri Lanka", "Filipinas", "Taiwán", "Singapur", "Emiratos Árabes Unidos"],
      dojosCount: "600+ Dojos",
      eventos: "Honbu Dojo Kagami Biraki, Campamentos de Verano en Sugamo Tokio, JKS World Championship.",
      descripcion: "Cuna del Karate Shotokan y sede central de la Japan Karate Shoto Federation. El Honbu Dojo en Tokio recibe anualmente a karatekas de todo el mundo."
    },
    africa: {
      nombre: "África",
      paises: ["Sudáfrica", "Egipto", "Kenia", "Ghana", "Marruecos", "Nigeria"],
      dojosCount: "120+ Dojos",
      eventos: "Campeonato Africano JKS, Programas de Formación Técnica y Arbitraje.",
      descripcion: "Comunidad marcial caracterizada por su entusiasmo, rigor marcial y participación activa en los Campeonatos Mundiales."
    }
  };

  function renderRegion(key) {
    const data = REGIONES[key];
    if (!data || !worldDataContainer) return;

    worldDataContainer.innerHTML = `
      <div class="region-detail-card fade-in">
        <div class="region-header">
          <h3>Región: ${data.nombre}</h3>
          <span class="region-badge">${data.dojosCount}</span>
        </div>
        <p class="region-desc">${data.descripcion}</p>
        
        <div class="region-content-grid">
          <div class="region-countries">
            <h4>Países Afiliados Destacados:</h4>
            <div class="countries-tags">
              ${data.paises.map(p => `<span class="country-tag">🌐 ${p}</span>`).join('')}
            </div>
          </div>
          <div class="region-events">
            <h4>Actividades y Seminarios:</h4>
            <p>🥋 ${data.eventos}</p>
          </div>
        </div>
      </div>
    `;
  }

  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      renderRegion(tab.dataset.region);
    });
  });

  // Render inicial región América
  renderRegion('america');
}

/* ==========================================================================
   5. FAQ ACCORDION (Preguntas Frecuentes)
   ========================================================================== */
function initFaqAccordion() {
  const faqItems = document.querySelectorAll('.faq-item');

  faqItems.forEach(item => {
    const question = item.querySelector('.faq-question');
    if (question) {
      question.addEventListener('click', () => {
        const isOpen = item.classList.contains('open');
        // Cerrar otros
        faqItems.forEach(i => i.classList.remove('open'));
        if (!isOpen) {
          item.classList.add('open');
        }
      });
    }
  });
}

/* ==========================================================================
   6. FORMULARIO DE CONTACTO & AFILIACIÓN
   ========================================================================== */
function initContactForm() {
  const form = document.getElementById('dojo-contact-form');
  const toast = document.getElementById('contact-toast');

  if (!form) return;

  form.addEventListener('submit', (e) => {
    e.preventDefault();

    const nombre = document.getElementById('nombre')?.value.trim();
    const email = document.getElementById('email')?.value.trim();
    const interes = document.getElementById('interes')?.value;
    const estado = document.getElementById('estado-interes')?.value;
    const mensaje = document.getElementById('mensaje')?.value.trim();

    if (!nombre || !email || !mensaje) {
      showToast('Por favor completa todos los campos requeridos.', 'error');
      return;
    }

    // Mensaje de éxito simulado (100% cliente sin backend requerido)
    const btnSubmit = form.querySelector('button[type="submit"]');
    const originalText = btnSubmit.innerHTML;
    btnSubmit.innerHTML = '<span>Enviando mensaje... ⏳</span>';
    btnSubmit.disabled = true;

    setTimeout(() => {
      form.reset();
      btnSubmit.innerHTML = originalText;
      btnSubmit.disabled = false;
      showToast(`¡Gracias ${nombre}! Tu mensaje ha sido recibido con éxito. Un instructor se comunicará contigo a la brevedad.`, 'success');
    }, 1000);
  });

  function showToast(msg, type = 'success') {
    if (!toast) {
      alert(msg);
      return;
    }
    toast.textContent = msg;
    toast.className = `contact-toast active ${type}`;
    setTimeout(() => {
      toast.classList.remove('active');
    }, 5000);
  }
}

/* ==========================================================================
   7. ANIMACIONES DE SCROLL (IntersectionObserver)
   ========================================================================== */
function initScrollAnimations() {
  const animatedElements = document.querySelectorAll('.reveal');

  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      });
    }, {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px'
    });

    animatedElements.forEach(el => observer.observe(el));
  } else {
    // Fallback para navegadores antiguos
    animatedElements.forEach(el => el.classList.add('visible'));
  }
}
